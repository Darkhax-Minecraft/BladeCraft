Mixer Dye Block-
This block is meant to have a central animated rotor that spins slowly when the block is active. It will also have a transparent rendered space for the "dye" inside the block, hopefully the color of the liquid will be the same as the player's actual dye. There is an object cube in the java file for this dye.

Mixer Block-
This is the backup if dye rendering is not possible. It will still have a spinning rotor.
